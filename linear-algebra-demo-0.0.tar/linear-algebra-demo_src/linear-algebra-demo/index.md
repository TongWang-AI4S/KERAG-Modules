<!-- Version: 0.0 -->
# 线性代数 [@linear-algebra]

线性代数是关于向量空间和线性映射的数学分支。
[@definition]

<!-- 矩阵部分 (引用) -->
## (@matrix::matrix)

<!-- 向量部分 (引用) -->
## (@vector::vector)
