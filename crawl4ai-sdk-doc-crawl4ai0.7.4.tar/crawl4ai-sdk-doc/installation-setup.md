# Installation & Setup [@installation-setup]

## Installation & Setup (2023 Edition) [@installation-setup-2023-edition]
### 1. Basic Installation [@1-basic-installation]
```bash
pip install crawl4ai
```
### 2. Initial Setup & Diagnostics [@2-initial-setup-diagnostics]
#### 2.1 Run the Setup Command [@2-1-run-the-setup-command]
```bash
crawl4ai-setup
```
- Performs OS-level checks (e.g., missing libs on Linux)
- Confirms your environment is ready to crawl
#### 2.2 Diagnostics [@2-2-diagnostics]
```bash
crawl4ai-doctor
```
- Check Python version compatibility
- Verify Playwright installation
- Inspect environment variables or library conflicts
If any issues arise, follow its suggestions (e.g., installing additional system packages) and re-run `crawl4ai-setup`.
### 3. Verifying Installation: A Simple Crawl (Skip this step if you already run `crawl4ai-doctor`) [@3-verifying-installation-a-simple-crawl-skip-this-step-if-you-already-run-`crawl4ai-doctor`]
Below is a minimal Python script demonstrating a **basic** crawl. It uses our new **`BrowserConfig`** and **`CrawlerRunConfig`** for clarity, though no custom settings are passed in this example:
```python
import asyncio
from crawl4ai import AsyncWebCrawler, BrowserConfig, CrawlerRunConfig

async def main():
    async with AsyncWebCrawler() as crawler:
        result = await crawler.arun(
            url="https://www.example.com",
        )
        print(result.markdown[:300])  # Show the first 300 characters of extracted text

if __name__ == "__main__":
    asyncio.run(main())
```
- A headless browser session loads `example.com`
- Crawl4AI returns ~300 characters of markdown.  
If errors occur, rerun `crawl4ai-doctor` or manually ensure Playwright is installed correctly.
### 4. Advanced Installation (Optional) [@4-advanced-installation-optional]
#### 4.1 Torch, Transformers, or All [@4-1-torch-transformers-or-all]
- **Text Clustering (Torch)**  
  ```bash
  pip install crawl4ai[torch]
  crawl4ai-setup
  ```
- **Transformers**  
  ```bash
  pip install crawl4ai[transformer]
  crawl4ai-setup
  ```
- **All Features**  
  ```bash
  pip install crawl4ai[all]
  crawl4ai-setup
  ```
```bash
crawl4ai-download-models
```
### 5. Docker (Experimental) [@5-docker-experimental]
```bash
docker pull unclecode/crawl4ai:basic
docker run -p 11235:11235 unclecode/crawl4ai:basic
```
You can then make POST requests to `http://localhost:11235/crawl` to perform crawls. **Production usage** is discouraged until our new Docker approach is ready (planned in Jan or Feb 2025).
### 6. Local Server Mode (Legacy) [@6-local-server-mode-legacy]
### Summary [@summary]
1. **Install** with `pip install crawl4ai` and run `crawl4ai-setup`.
2. **Diagnose** with `crawl4ai-doctor` if you see errors.
3. **Verify** by crawling `example.com` with minimal `BrowserConfig` + `CrawlerRunConfig`.



