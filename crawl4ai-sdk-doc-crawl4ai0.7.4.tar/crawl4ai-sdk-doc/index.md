<!-- Version: crawl4ai0.7.4 -->
<!-- Description: Crawl4AI Complete SDK Documentation Copied from Official Site -->
<!-- Copied from https://docs.crawl4ai.com/complete-sdk-reference/ , removed the "navigation" section, adjusted the section level and then fed into `kerag tool split`, then renamed the outermost label to "crawl4ai-sdk-doc" for simplicity  -->

# Crawl4AI Complete SDK Documentation [@crawl4ai-sdk-doc]

**Generated:** 2025-10-19 12:56
**Format:** Ultra-Dense Reference (Optimized for AI Assistants)
**Crawl4AI Version:** 0.7.4

---

## (@installation-setup::installation-setup)

## (@quick-start::quick-start)

## (@core-api::core-api)

## (@configuration::configuration)

## (@crawling-patterns::crawling-patterns)

## (@content-processing::content-processing)

## (@extraction-strategies::extraction-strategies)

## (@advanced-features::advanced-features)

