# 向量 [@vector]
向量是具有大小和方向的量。

## 参见
(@matrix::matrix): 矩阵的介绍
<!-- 引用index目录中的内容 -->
(@index::definition)
